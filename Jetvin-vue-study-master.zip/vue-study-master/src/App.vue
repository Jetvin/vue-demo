<template>
  <div id="app" :style="{height: '100%'}"><router-view/></div>
</template>

<script>
export default {
  name: 'App'
}
</script>

<style>
  html,body{
    height: 100%;
    padding: 0; margin: 0;
    background-color: #fff;
  }
</style>


