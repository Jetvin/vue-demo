<template>
  <div id="UnionMember">
    <div>
      <el-row type="flex" :style="{height: '80px'}">
        <el-col :span="4">
          <el-row type="flex" justify="space-between">
            <el-col :span="12">
              <el-button type="primary" @click="dialogVisible = true" icon="el-icon-plus" plain>新增</el-button>
              <el-dialog title="新建" :visible.sync="dialogVisible" width="30%">
                <el-form label-position="right" label-width="80px" :model="unionMember">
                  <el-form-item label="姓名">
                    <el-input v-model="unionMember.userName" clearable @change="change"></el-input>
                  </el-form-item>
                  <el-form-item label="性别">
                    <el-radio-group v-model="unionMember.sex">
                      <el-radio label="男">男</el-radio>
                      <el-radio label="女">女</el-radio>
                    </el-radio-group>
                  </el-form-item>
                  <el-form-item label="联系方式">
                    <el-input v-model="unionMember.phone" clearable @change="change"></el-input>
                  </el-form-item>
                  <el-form-item label="邮箱">
                    <el-input v-model="unionMember.email" clearable @change="change"></el-input>
                  </el-form-item>
                  <el-form-item label="证件号码">
                    <el-input v-model="unionMember.credentailsNumber" clearable @change="change"></el-input>
                  </el-form-item>
                  <el-form-item label="所属工会">
                    <el-select v-model="unionMember.unionName" placeholder="请选择所属工会" clearable>
                      <el-option v-for="item in unionOptions" :key="item.unionId" :label="item.unionName"
                                 :value="item.unionId"></el-option>
                    </el-select>
                  </el-form-item>
                  <el-form-item label="入会日期">
                    <el-date-picker v-model="unionMember.initiateDate" type="date" placeholder="选择日期">
                    </el-date-picker>
                  </el-form-item>
                </el-form>
                <span slot="footer" class="dialog-footer">
                    <el-button type="primary" @click="">新建</el-button>
                    <el-button @click="dialogVisible = false">取消</el-button>
                </span>
              </el-dialog>
            </el-col>
            <el-col :span="12">
              <el-button type="danger" :disabled="deleteButtonDisabled" @click="handleClearSelection"
                         icon="el-icon-delete" plain>删除
              </el-button>
            </el-col>
          </el-row>
        </el-col>
        <el-col :span="20">
          <el-row type="flex" :gutter="20" justify="end">
            <el-col :span="4" :style="{marginLeft: ''}">
              <el-select v-model="unionValue" placeholder="请选择所属工会" clearable @change="handleSearch">
                <el-option v-for="item in unionOptions" :key="item.unionId" :label="item.unionName"
                           :value="item.unionId"></el-option>
              </el-select>
            </el-col>
            <el-col :span="4">
              <el-input placeholder="请输入检索内容" @keyup.enter.native="handleSearch" v-model="searchValue">
                <el-button slot="append" icon="el-icon-search" @click="handleSearch"></el-button>
              </el-input>
            </el-col>
            <el-col :span="2">
              <el-button type="primary" @click="" icon="el-icon-download" plain>导出</el-button>
            </el-col>
          </el-row>
        </el-col>
      </el-row>
    </div>
    <div :style="{backgroundColor: '#fff', padding: '0 10px 0 10px', minHeight: '570px', position: 'relative'}">
      <div>
        <el-table ref="unionMemberTable" :data="tableData"
                  @select="handleTableRowSelect"
                  @select-all="handleTableRowSelect"
        >
          <el-table-column type="selection" width="55"></el-table-column>
          <el-table-column prop="userName" label="姓名"></el-table-column>
          <el-table-column prop="sex" label="性别"></el-table-column>
          <el-table-column prop="phone" label="联系方式"></el-table-column>
          <el-table-column prop="email" label="邮箱"></el-table-column>
          <el-table-column prop="credentailsNumber" label="证件号码"></el-table-column>
          <el-table-column prop="unionName" label="所属工会"></el-table-column>
          <el-table-column prop="initiateDate" label="入会日期"></el-table-column>
          <el-table-column fixed="right" label="操作">
            <template slot-scope="scope">
              <el-button type="text" size="small" @click="handlGet(scope.row.id)">查看</el-button>
              <el-button type="text" size="small">编辑</el-button>
              <el-button type="text" size="small" @click.native.prevent="handleTableRowDelete(scope.$index, tableData)">
                删除
              </el-button>
            </template>
          </el-table-column>
        </el-table>
      </div>
      <div :style="{position: 'absolute', bottom: '10px', right: '20px'}">
        <el-pagination background layout="prev, pager, next, jumper"
                       :total="tableTotal"
                       :page-size="pageSize"
                       @current-change="getTableData"
                       @pre-click="getTableData"
                       @next-click="getTableData"
        >
        </el-pagination>
      </div>
    </div>
  </div>
</template>

<script>
  export default {
    name: 'UnionDescription',
    data: () => ({
      dialogVisible: false,
      deleteButtonDisabled: true,
      tableData: [],
      tableTotal: 1,
      tableSelection: [],
      pageSize: 8,
      pageNum: 1,
      unionValue: '',
      searchValue: '',
      unionOptions: [],
      unionMember:{
        credentailsNumber: '',
        userName: '',
        sex: '',
        phone: '',
        email: '',
        unionName: '',
        initiateDate: ''
      }
    }),
    mounted () {
      this.getTableData(this.pageNum)
      this.getUnionData()
    },
    methods: {
      // TODO 获取工会下拉框
      getUnionData () {
        this.$http.post('/union/common/getAllUnionName',
          {}, {
            headers: {
              token: this.GLOBAL.data().token
            }
          }
        ).then((res) => {
          this.unionOptions = res.body.info.list
        })
      },
      // TODO 获取列表数据
      getTableData (pageNum) {
        console.log(`当前页: ${pageNum}`)
        this.searchTableData(pageNum)
      },
      // TODO 检索列表
      searchTableData (pageNum) {
        this.$http.post('/union/unionMember/getUnionMemberList',
          {
            pageSize: this.pageSize,
            pageNum: pageNum,
            unionId: this.unionValue,
            searchWord: this.searchValue
          }, {
            headers: {
              token: this.GLOBAL.data().token
            }
          }
        ).then((res) => {
          this.tableData = res.body.info.list
          this.tableTotal = res.body.info.total
        })
      },
      // TODO 处理检索
      handleSearch () {
        this.searchTableData(this.pageNum)
      },
      // TODO 处理列表数据行勾选
      handleTableRowSelect (selection, row) {
        if (selection.length > 0) {
          this.deleteButtonDisabled = false
        } else {
          this.deleteButtonDisabled = true
        }

        this.tableSelection = selection
        console.log(selection)
        console.log(row)
      },
      // TODO 移除列表数据行(不是删除，删除要掉接口并移除，至于耍不刷新看需求)
      handleTableRowDelete (index, rows) {

        this.$confirm('确认删除选中记录吗？', '提示',
          {
            'type': 'warning'
          }).then(() => {

          rows.splice(index, 1)

          this.$message({
            showClose: true,
            message: '删除记录成功',
            type: 'success'
          })
        }).catch(() => {
        })
      },
      // TODO 移除列表数据行[多选](不是删除，删除要掉接口并移除，至于耍不刷新看需求)
      handleClearSelection () {

        this.$confirm('确认删除选中记录吗？', '提示',
          {
            'type': 'warning'
          }).then(() => {

          this.tableSelection.forEach((value, index) => {
            this.tableData.forEach((v, i) => {
              if (value.id == v.id) {
                this.tableData.splice(i, 1)
              }
            })
          })

          this.$message({
            showClose: true,
            message: '删除记录成功',
            type: 'success'
          })
        }).catch(() => {
        })
      },
      change(value){
        console.log(value);
      },
      handlGet(id){
        console.log(id + '---');
        this.$router.push({
          name: 'UnionMemberDetail',
          query: {
            id: id
          },
          params: {
            id: id
          }
        })
      }
    }
  }
</script>

<style scoped>
</style>

