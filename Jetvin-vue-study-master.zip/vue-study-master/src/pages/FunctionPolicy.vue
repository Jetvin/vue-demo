<template>
  <div id="FunctionPolicy">这是政策法规页面页面</div>
</template>

<script>
export default {
  name: "FunctionPolicy"
};
</script>

<style scoped>
</style>

