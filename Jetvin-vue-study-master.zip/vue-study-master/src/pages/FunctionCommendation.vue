<template>
  <div id="FunctionCommendation">这是表彰先进页面</div>
</template>

<script>
export default {
  name: "FunctionCommendation"
};
</script>

<style scoped>
</style>

