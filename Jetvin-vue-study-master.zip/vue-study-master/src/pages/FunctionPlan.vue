<template>
  <div id="FunctionPlan">这是工作计划页面</div>
</template>

<script>
export default {
  name: "FunctionPlan"
};
</script>

<style scoped>
</style>

