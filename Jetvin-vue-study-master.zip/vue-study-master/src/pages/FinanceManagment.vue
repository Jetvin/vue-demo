<template>
  <div id="FinanceManagment">这是财务管理页面</div>
</template>

<script>
export default {
  name: "FinanceManagment"
};
</script>

<style scoped>
</style>

