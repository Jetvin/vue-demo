<template>
  <div id="BookManagment">这是数籍管理页面</div>
</template>

<script>
export default {
  name: "BookManagment"
};
</script>

<style scoped>
</style>

