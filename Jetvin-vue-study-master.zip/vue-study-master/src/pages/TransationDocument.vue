<template>
  <div id="TransactionDocument">这是公文传递页面</div>
</template>

<script>
export default {
  name: "TransactionDocument"
};
</script>

<style scoped>
</style>

