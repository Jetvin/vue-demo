<template>
  <div id="FunctionActivityDisplay">这是工会活动展示页面</div>
</template>

<script>
export default {
  name: "FunctionActivityDisplay"
};
</script>

<style scoped>
</style>

