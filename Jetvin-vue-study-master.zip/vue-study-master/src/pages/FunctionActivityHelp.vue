<template>
  <div id="FunctionActivityHelp">这是困难帮扶页面</div>
</template>

<script>
export default {
  name: "FunctionActivityHelp"
};
</script>

<style scoped>
</style>

