<template>
  <div id="SystemUser">这是用户管理页面</div>
</template>

<script>
export default {
  name: "SystemUser"
};
</script>

<style scoped>
</style>

