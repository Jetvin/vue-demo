<template>
  <div id="FunctionTraining">这是职工培训页面</div>
</template>

<script>
export default {
  name: "FunctionTraining"
};
</script>

<style scoped>
</style>

