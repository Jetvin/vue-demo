<template>
  <div id="FunctionMinute">这是会议记录页面</div>
</template>

<script>
export default {
  name: "FunctionMinute"
};
</script>

<style scoped>
</style>

