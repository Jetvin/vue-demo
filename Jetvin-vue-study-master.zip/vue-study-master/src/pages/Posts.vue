<template>
  <div id="Posts">这是帖子管理页面</div>
</template>

<script>
export default {
  name: "Posts"
};
</script>

<style scoped>
</style>

