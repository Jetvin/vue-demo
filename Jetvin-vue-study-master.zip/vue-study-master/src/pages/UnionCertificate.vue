<template>
  <div id="UnionDescription">这是工会法人证页面</div>
</template>

<script>
export default {
  name: "UnionDescription"
};
</script>

<style scoped>
</style>

