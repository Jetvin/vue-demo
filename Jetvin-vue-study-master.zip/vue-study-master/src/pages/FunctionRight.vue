<template>
  <div id="FunctionRight">这是权益维护页面</div>
</template>

<script>
export default {
  name: "FunctionRight"
};
</script>

<style scoped>
</style>

