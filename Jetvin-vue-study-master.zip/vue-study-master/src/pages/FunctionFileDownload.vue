<template>
  <div id="FunctionFileDownload">这是文件下载页面</div>
</template>

<script>
export default {
  name: "FunctionFileDownload"
};
</script>

<style scoped>
</style>

