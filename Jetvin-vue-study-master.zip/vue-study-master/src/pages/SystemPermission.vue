<template>
  <div id="SystemPermission">这是权限管理页面</div>
</template>

<script>
export default {
  name: "SystemPermission"
};
</script>

<style scoped>
</style>

