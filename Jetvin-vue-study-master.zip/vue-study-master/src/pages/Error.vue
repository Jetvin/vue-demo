<template>
  <div class="container">
    <img src="http://113.105.128.165:10003/static/404.png" height="200" alt="瞎鸡巴乱写" />
    <div class="subText">
            <span>
                error
            </span>
      <div>

      </div>
    </div>
    <p class="sorryText">兄嘚，404啦</p>
    <div class="callBackBtn"><a href="/index">返回登录页</a></div>
  </div>
</template>

<script>
  export default {
    name: 'Error'
  }
</script>

<style scoped>
  .container {
    height: 70vh;
    padding-top: 65px;
    text-align: center;
    width: 530px;
    margin: 0 auto;
  }
  .sorryText {
    font-size: 20px;
    color: #999999;
  }
  .callBackBtn {
    text-align: center;
    margin-top: 31px;
  }
  .callBackBtn > a {
    cursor: pointer;
    display: inline-block;
    text-decoration: none;
    width: 100px;
    height: 36px;
    line-height: 36px;
    background: #0d4077;
    text-align: center;
    color: #fff;
    font-size: 14px;
    border-radius: 4px;
  }
  .subText {
    float: right;
    padding-top: 15px;
    color: #0d4077;
    font-family: PingFang SC,Microsoft YaHei,sans-serif;
    font-size: 26px;
  }
  .subText span {
    font-size: 96px;
  }
</style>
