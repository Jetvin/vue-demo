<template>
  <div id="FinaceDisplay">这是财务数据展示页面</div>
</template>

<script>
export default {
  name: "FinaceDisplay"
};
</script>

<style scoped>
</style>

