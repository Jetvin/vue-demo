<template>
  <div :style="{backgroundColor: '#fff'}">
    <el-card shadow="never" :style="{border: '0'}">
      <div slot="header">
        <span>基本信息</span>
      </div>
      <el-form :inline="true" :model="unionMember" label-width="100px" label-position="right">
        <el-row justify="space-between">
          <el-col :span="6">
            <el-form-item label="姓名" required>
              <el-input prefix-icon="el-icon-edit-outline" v-model="unionMember.userName" placeholder="姓名"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="性别" required>
              <el-radio-group v-model="unionMember.sex">
                <el-radio label="男">男</el-radio>
                <el-radio label="女">女</el-radio>
              </el-radio-group>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="联系方式" required>
              <el-input prefix-icon="el-icon-edit-outline" v-model="unionMember.phone" placeholder="联系方式"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="邮箱" required>
              <el-input prefix-icon="el-icon-edit-outline" v-model="unionMember.email" placeholder="邮箱"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <el-form :inline="true" :model="unionMember" label-width="100px" label-position="right">
        <el-row justify="space-between">
          <el-col :span="6">
            <el-form-item label="出生日期">
              <el-date-picker v-model="unionMember.birthday" type="date" placeholder="出生日期"></el-date-picker>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="民族">
              <el-input prefix-icon="el-icon-edit-outline" v-model="unionMember.nation" placeholder="民族"
                        :style=""></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="文化程度">
              <el-input prefix-icon="el-icon-edit-outline" v-model="unionMember.educationDegree"
                        placeholder="文化程度"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="籍贯">
              <el-input prefix-icon="el-icon-edit-outline" v-model="unionMember.natives" placeholder="籍贯"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <el-form :inline="true" :model="unionMember" label-width="100px" label-position="right">
        <el-row justify="space-between">
          <el-col :span="6">
            <el-form-item label="证件类型" required>
              <el-input prefix-icon="el-icon-edit-outline" v-model="unionMember.credentailsType"
                        placeholder="证件类型"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="证件号码" required>
              <el-input prefix-icon="el-icon-edit-outline" v-model="unionMember.credentailsNumber"
                        placeholder="证件号码"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="所属工会" required>
              <el-input prefix-icon="el-icon-edit-outline" v-model="unionMember.unionName" placeholder="所属工会"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="入会日期">
              <el-date-picker v-model="unionMember.initiateDate" type="date" placeholder="入会日期"></el-date-picker>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <el-form :inline="true" :model="unionMember" label-width="100px" label-position="right">
        <el-row justify="space-between">
          <el-col :span="6">
            <el-form-item label="入职日期">
              <el-date-picker v-model="unionMember.entryDate" type="date" placeholder="入职日期"></el-date-picker>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="离职日期">
              <el-date-picker v-model="unionMember.dimissionDate" type="date" placeholder="离职日期"></el-date-picker>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="用户权限" required>
              <el-input prefix-icon="el-icon-edit-outline" v-model="unionMember.roleName" placeholder="用户权限"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="6"></el-col>
        </el-row>
      </el-form>
    </el-card>
    <el-card shadow="never" :style="{border: '0'}">
      <div slot="header">
        <span>修改密码</span>
      </div>
      <el-form status-icon label-width="100px" :style="{width: '400px'}">
        <el-form-item label="密码">
          <el-input type="password" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="确认密码">
          <el-input type="password" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="">修改</el-button>
        </el-form-item>
      </el-form>
    </el-card>
    <el-card shadow="never" :style="{border: '0', minHeight: '250px', position: 'relative'}">
      <div slot="header">
        <span>密码修改记录</span>
      </div>
      <el-table ref="unionMemberTable" :data="tableData">
        <el-table-column prop="id" label="序号"></el-table-column>
        <el-table-column prop="createTime" label="修改时间"></el-table-column>
        <el-table-column prop="userName" label="修改人名称"></el-table-column>
        <el-table-column prop="ip" label="修改人IP"></el-table-column>
        <el-table-column prop="message" label="信息"></el-table-column>
      </el-table>
      <div :style="{position: 'absolute', bottom: '10px', right: '20px'}">
        <el-pagination background layout="prev, pager, next, jumper"
                       :total="tableTotal"
                       :page-size="pageSize"
                       @current-change=""
                       @pre-click=""
                       @next-click=""
        >
        </el-pagination>
      </div>
    </el-card>
  </div>
</template>

<script>
  export default {
    name: 'UnionMemberDetail',
    data: () => ({
      tableTotal: 0,
      pageSize: 1,
      unionMember: {
        birthday: '',
        credentailsNumber: '',
        credentailsType: '',
        credentailsTypeId: '',
        dimissionDate: '',
        educationDegree: '',
        educationDegreeId: '',
        email: '',
        entryDate: '',
        id: '',
        initiateDate: '',
        nation: '',
        natives: '',
        phone: '',
        roleId: '',
        roleName: '',
        sex: '',
        unionId: '',
        unionName: '',
        userId: '',
        userName: ''
      }
    }),
    mounted () {
      console.log(this.$route.query)
      this.$http.post('/union/user/get',
        {
          userId: this.$route.query.id
        }, {
          headers: {
            token: this.GLOBAL.data().token
          }
        }
      ).then((res) => {
        console.log(res.body.info)
        this.unionMember = res.body.info
      })
    }
  }
</script>

<style scoped>

</style>
