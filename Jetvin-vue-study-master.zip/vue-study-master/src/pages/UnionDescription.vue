<template>
  <div id="UnionDescription">
    这工会是会组织概述页面
    <div>
      <video src="http://ccms.dgut.edu.cn/cms/articleFile/static/19226a6ecae7e8824057a3d378d771d2" controls></video>
    </div>
  </div>

</template>

<script>
export default {
  name: "UnionDescription"
};
</script>

<style scoped>
</style>

