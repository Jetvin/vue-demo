<template>
  <div id="SystemLogOperate">这是操作日志页面</div>
</template>

<script>
export default {
  name: "SystemLogOperate"
};
</script>

<style scoped>
</style>

