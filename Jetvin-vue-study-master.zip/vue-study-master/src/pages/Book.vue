<template>
  <div id="Book">这是书籍页面</div>
</template>

<script>
export default {
  name: "Book"
};
</script>

<style scoped>
</style>

