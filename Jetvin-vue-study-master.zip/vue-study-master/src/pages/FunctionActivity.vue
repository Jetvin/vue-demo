<template>
  <div id="FunctionActivity">这是工会活动页面</div>
</template>

<script>
export default {
  name: "FunctionActivity"
};
</script>

<style scoped>
</style>

