<template>
  <div id="FunctionDocument">这是困难职工档案页面</div>
</template>

<script>
export default {
  name: "FunctionDocument"
};
</script>

<style scoped>
</style>

