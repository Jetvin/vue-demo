<template>
  <div id="TransactionNotice">这是通知公告页面</div>
</template>

<script>
export default {
  name: "TransactionNotice"
};
</script>

<style scoped>
</style>

