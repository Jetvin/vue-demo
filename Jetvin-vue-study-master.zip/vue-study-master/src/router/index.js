import Vue from 'vue'
import Router from 'vue-router'
import index from '../components/index.vue'
import UnionMember from '../pages/UnionMember'
import UnionDescription from '../pages/UnionDescription'
import UnionCertificate from '../pages/UnionCertificate'

import Book from '../pages/Book'
import BookManagment from '../pages/BookManagment'
import FinanceDisplay from '../pages/FinanceDisplay'
import FinanceManagment from '../pages/FinanceManagment'
import FunctionActivity from '../pages/FunctionActivity'
import FunctionActivityDisplay from '../pages/FunctionActivityDisplay'
import FunctionActivityHelp from '../pages/FunctionActivityHelp'
import FunctionCommendation from '../pages/FunctionCommendation'
import FunctionFileDownload from '../pages/FunctionFileDownload'
import FunctionMinute from '../pages/FunctionMinute'
import FunctionPlan from '../pages/FunctionPlan'
import FunctionPolicy from '../pages/FunctionPolicy'
import FunctionRight from '../pages/FunctionRight'
import FunctionTraining from '../pages/FunctionTraining'
import FunctionDocument from '../pages/FunctionDocument'
import Posts from '../pages/Posts'
import SystemLogLogin from '../pages/SystemLogLogin'
import SystemLogOperate from '../pages/SystemLogOperate'
import SystemPermission from '../pages/SystemPermission'
import SystemUser from '../pages/SystemUser'
import TransationDocument from '../pages/TransationDocument'
import TransationNotice from '../pages/TransationNotice'
import TransationTask from '../pages/TransationTask'
import error from '../pages/Error'
import UnionMemberDetail from '../pages/UnionMemberDetail'

Vue.use(Router)

export default new Router({
  // 去掉#，默认hash
  mode: 'history',
  routes: [
    {
      path: '/error',
      component: error,
    },
    {
      path: '/',
      redirect: '/index/union/member'
    },
    {
      path: '/index',
      redirect: '/index/union/member'
    },
    {
      path: '/index',
      name: 'index',
      component: index,
      children: [
        {
          meta: {titles: ['组织建设', '会员管理']},
          path: 'union/member',
          name: 'UnionMember',
          component: UnionMember
        },
        {
          meta: {titles: ['组织建设', '会员管理', '会员详情']},
          path: 'union/member/detail',
          name: 'UnionMemberDetail',
          component: UnionMemberDetail
        },
        {
          meta: {titles: ['组织建设', '组织概述']},
          path: 'union/description',
          name: 'UnionDescription',
          component: UnionDescription
        },
        {
          meta: {titles: ['组织建设', '工会管理', '法人证管理']},
          path: 'union/certificate',
          name: 'UnionCertificate',
          component: UnionCertificate
        },
        {
          path: 'book',
          name: 'Book',
          component: Book
        },
        {
          path: 'book/management',
          name: 'BookManagment',
          component: BookManagment
        },
        {
          path: 'finance/display',
          name: 'FinanceDisplay',
          component: FinanceDisplay
        },
        {
          path: 'finance/managment',
          name: 'FinanceManagment',
          component: FinanceManagment
        },
        {
          path: 'function/activity',
          name: 'FunctionActivity',
          component: FunctionActivity
        },
        {
          path: 'function/display',
          name: 'FunctionActivityDisplay',
          component: FunctionActivityDisplay
        },
        {
          path: 'function/help',
          name: 'FunctionActivityHelp',
          component: FunctionActivityHelp
        },
        {
          path: 'function/commendation',
          name: 'FunctionCommendation',
          component: FunctionCommendation
        },
        {
          path: 'function/file/download',
          name: 'FunctionFileDownload',
          component: FunctionFileDownload
        },
        {
          path: 'function/minute',
          name: 'FunctionMinute',
          component: FunctionMinute
        },
        {
          path: 'function/plan',
          name: 'FunctionPlan',
          component: FunctionPlan
        },
        {
          path: 'function/policy',
          name: 'FunctionPolicy',
          component: FunctionPolicy
        },
        {
          path: 'function/right',
          name: 'FunctionRight',
          component: FunctionRight
        },
        {
          path: 'function/training',
          name: 'FunctionTraining',
          component: FunctionTraining
        },
        {
          path: 'function/document',
          name: 'FunctionDocument',
          component: FunctionDocument
        },
        {
          path: 'posts',
          name: 'Posts',
          component: Posts
        },
        {
          path: 'system/log/login',
          name: 'SystemLogLogin',
          component: SystemLogLogin
        },
        {
          path: 'system/log/operate',
          name: 'SystemLogOperate',
          component: SystemLogOperate
        },
        {
          path: 'system/permission',
          name: 'SystemPermission',
          component: SystemPermission
        },
        {
          path: 'system/user',
          name: 'SystemUser',
          component: SystemUser
        },
        {
          path: 'transation/document',
          name: 'TransationDocument',
          component: TransationDocument
        },
        {
          path: 'transation/notice',
          name: 'TransationNotice',
          component: TransationNotice
        },
        {
          path: 'transation/task',
          name: 'TransationTask',
          component: TransationTask
        }
      ]
    }
  ]
})
