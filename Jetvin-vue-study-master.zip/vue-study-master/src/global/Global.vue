<template>
    <div>

    </div>
</template>

<script>
  export default {
    name: 'global',
    data: () => ({
      routerViewName: '全局路由名称初始化',
      token: 'java'
    })
  }
</script>

<style scope>

</style>
