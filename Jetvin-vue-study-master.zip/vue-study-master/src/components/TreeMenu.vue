<template>
    <div>
      <template v-for="item in menuData">
        <el-submenu :index="item.name" v-if="item.children">
          <template slot="title">
            <i class="el-icon-menu"></i>
            <span>{{item.name}}</span>
          </template>
          <TreeMenu :menuData="item.children"/>
        </el-submenu>
        <el-menu-item :index="item.routerLink" :key="item.routerLink" v-else>
          <span slot="title">{{item.name}}</span>
        </el-menu-item>
      </template>
    </div>
</template>

<script>
  export default {
    name: 'TreeMenu',
    props:[
      'menuData'
    ]
  }
</script>

<style scoped>

</style>
