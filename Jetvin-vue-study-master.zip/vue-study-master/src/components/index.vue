<template>
  <div :style="{height: '100%'}">
    <el-container :style="{height: '100%'}">
      <el-aside :style="{width: '300px', height: '100%', borderRight: 'solid 1px #e6e6e6'}">
        <el-menu ref="element-menu" :style="{ borderRight: 'solid 0px #e6e6e6', height: '100%'}"
                 class="el-menu-vertical-demo" router unique-opened :default-active="$route.path"
                 @select="handleMenuSelected"
                 @open="handleMenuOpen"
                 background-color=""
        >
          <TreeMenu :menuData="menuData"/>
        </el-menu>
      </el-aside>
      <el-container :style="{backgroundColor: '#f0f2f5', height: '100%'}">
        <el-header :style="{padding: '25px 0', backgroundColor: '#fff', height: '80px'}">
          <el-row type="flex" justify="space-around">
            <el-col :span="22" :style="{padding: '5px 0'}">
              <el-breadcrumb separator="/">
                <template v-for="item in getBreadcrumb">
                  <el-breadcrumb-item>{{item}}</el-breadcrumb-item>
                </template>
              </el-breadcrumb>
            </el-col>
            <el-col :span="1">
              <el-dropdown placement="bottom">
                <el-button size="small" icon="el-icon-more" circle></el-button>
                <el-dropdown-menu slot="dropdown">
                  <el-dropdown-item>个人资料</el-dropdown-item>
                  <el-dropdown-item>注销</el-dropdown-item>
                </el-dropdown-menu>
              </el-dropdown>
            </el-col>
          </el-row>
        </el-header>
        <!--#EFEFEF-->
        <el-main :style="{backgroundColor: '#fff', margin: '30px'}">
          <router-view/>
        </el-main>
        <el-footer :style="{textAlign: 'center'}">Vue Study ©2018 Created by Jetvin</el-footer>
      </el-container>
    </el-container>
  </div>
</template>

<script>
  import menuData from '../json/inlineMenuData'
  import TreeMenu from './TreeMenu'

  export default {
    name: 'index2',
    components: {TreeMenu},
    data: () => ({
      menuData,
      breadcrumb: []
    }),
    methods: {
      handleMenuSelected (index, indexPath) {

      },
      handleMenuOpen (index, indexPath) {

      }
    },
    computed: {
      getBreadcrumb () {
        return this.breadcrumb
      }
    },
    mounted () {
      this.breadcrumb = this.$route.meta.titles
    },
    watch: {
      $route () {
        this.breadcrumb = this.$route.meta.titles
      }
    }
  }
</script>

<style scoped>

</style>
